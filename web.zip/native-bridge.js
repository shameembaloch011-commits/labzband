/** Native container facade. No SDK keys, fake ads, payments or browser rewards. */
(function (window) {
  'use strict';
  var adPending = null, purchasePending = null, queryPending = null;
  var consumePending = Object.create(null), listeners = Object.create(null);
  var ready = false, backHandler = null;
  function call(method, fallback) {
    var b = window.AndroidBridge;
    if (!b || typeof b[method] !== 'function') return fallback;
    try { return b[method].apply(b, Array.prototype.slice.call(arguments, 2)); }
    catch (_) { return fallback; }
  }
  function parse(value) {
    try { var data = typeof value === 'string' ? JSON.parse(value) : value;
      return data && typeof data === 'object' ? data : {}; } catch (_) { return {}; }
  }
  function emit(name, data) {
    (listeners[name] || []).slice().forEach(function (fn) { try { fn(data); } catch (e) { console.error(e); } });
  }
  function on(name, fn) {
    (listeners[name] = listeners[name] || []).push(fn);
    return function () { listeners[name] = listeners[name].filter(function (item) { return item !== fn; }); };
  }
  function event(name, data) { window.dispatchEvent(new CustomEvent(name, { detail: data })); }
  function fail(reason) { return { ok: false, success: false, rewardGranted: false, reason: reason }; }
  function request(timeout) {
    var entry = { done: false };
    entry.promise = new Promise(function (resolve) {
      entry.finish = function (result) {
        if (entry.done) return;
        entry.done = true; clearTimeout(entry.timer); resolve(result);
      };
      // Retain the in-flight slot on timeout: without request IDs a late native
      // callback MUST NOT be attributed to a subsequent purchase or reward.
      entry.timer = setTimeout(function () { entry.finish(fail('TIMEOUT')); }, timeout);
    });
    return entry;
  }
  function show(kind, method, args) {
    if (adPending) return Promise.resolve(fail('BUSY'));
    var entry = request(180000);
    entry.kind = kind; entry.reward = false; adPending = entry;
    var accepted = call.apply(null, [method, false].concat(args || []));
    if (accepted !== true) { adPending = null; entry.finish(fail('NOT_AVAILABLE')); }
    return entry.promise;
  }
  var lastAdEnvelope = null;
  function adEvent(value) {
    // The container delivers every ad event twice on purpose (NativeAds.onEvent
    // and a `nativeads:event` DOM event, so either integration style works);
    // this facade listens to both, so the second copy is dropped here.
    var e = parse(value), data = parse(e.data), entry = adPending, type = e.type;
    var key = type + '|' + JSON.stringify(data);
    if (key === lastAdEnvelope) return;
    lastAdEnvelope = key;
    setTimeout(function () { if (lastAdEnvelope === key) lastAdEnvelope = null; }, 0);
    if (entry) {
      if (entry.kind === 'rewarded' && (type === 'reward_granted' || type === 'rewarded_completed')) entry.reward = true;
      var closed = type === entry.kind + '_closed' || (entry.kind === 'native' && type === 'native_shown');
      // `interstitial_skipped`: the container suppressed the ad (remove-ads
      // owned) – for the game that is a closed ad, not an error.
      var skipped = type === entry.kind + '_skipped';
      var error = type === 'ad_error' && (!data.adType || data.adType === entry.kind || data.adType === 'sdk');
      if (closed || skipped || error) {
        adPending = null;
        var granted = !error && (entry.reward || data.rewardGranted === true);
        entry.finish(error ? fail(data.error || 'AD_ERROR') : {
          ok: entry.kind !== 'rewarded' || granted, type: entry.kind,
          rewardGranted: entry.kind === 'rewarded' && granted,
          reason: skipped ? 'SKIPPED' : (entry.kind === 'rewarded' && !granted ? 'NOT_REWARDED' : undefined), data: data
        });
      }
    }
    emit('ads:' + type, data); emit('ads:event', e);
  }
  window.NativeApp = {
    isNative: function () { return !!window.AndroidBridge; },
    appReady: function () { if (!ready) ready = call('appReady', false) === true; return ready; },
    getInfo: function () { return parse(call('getInfo', '{}')); },
    getStartupRoute: function () { var route = call('getStartupRoute', ''); call('consumeStartupRoute', null); return route || ''; },
    reportError: function (message) { call('reportError', null, String(message)); },
    navigateBack: function () { return call('navigateBack', false) === true; },
    setBackHandler: function (fn) { backHandler = fn; },
    onBackPressed: function () { try { return !!backHandler && backHandler() === true; } catch (_) { return false; } },
    // Container must implement ACTION_SENDTO, mailto URI, prefer Gmail, then resolver.
    openEmail: function (address) { return call('openEmail', false, String(address)) === true; },
    // Native mirror of a saved-state blob (SharedPreferences, written at once).
    // localStorage is per *origin* and committed lazily by Chromium; the mirror
    // survives a changed loopback port, a force stop and a low-memory kill.
    // saveState(key, json, savedAtMillis) -> true when accepted;
    // loadState(key) -> { key, value, savedAt } or null.
    saveState: function (key, value, savedAt) {
      return call('saveState', false, String(key), String(value), String(savedAt == null ? Date.now() : savedAt)) === true;
    },
    loadState: function (key) {
      var raw = call('loadState', null, String(key));
      if (!raw || typeof raw !== 'string') return null;
      try { var o = JSON.parse(raw); return o && typeof o === 'object' && typeof o.value === 'string' ? o : null; } catch (_) { return null; }
    },
    on: function (name, fn) { return on('app:' + name, fn); },
    onEvent: function (value) { var e = parse(value); emit('app:' + e.type, e.data || e); emit('app:event', e); }
  };
  window.NativeAds = {
    showInterstitial: function () { return show('interstitial', 'showInterstitial'); },
    showRewarded: function () { return show('rewarded', 'showRewarded'); },
    showNative: function () { return show('native', 'showNative'); },
    showNativeAt: function (x, y, w, h) { return show('native', 'showNativeAt', [x|0,y|0,w|0,h|0]); },
    hideNative: function () { return call('hideNative', false) === true; },
    isReady: function (type) { return call('isAdReady', false, type) === true; },
    isAvailable: function () { return call('isAdsAvailable', false) === true; },
    prepare: function () { call('prepareAds', null); },
    on: function (name, fn) { return on('ads:' + name, fn); }, onEvent: adEvent
  };
  window.CafeBazaar = {
    isNativeBridgeAvailable: window.NativeApp.isNative,
    isAvailable: function () { return call('isBillingAvailable', false) === true; },
    connect: function () { return call('connectBilling', false) === true; },
    getInfo: window.NativeApp.getInfo,
    purchase: function (productId, payload) {
      if (purchasePending) return Promise.resolve(fail('BUSY'));
      if (!this.isAvailable()) return Promise.resolve(fail('NOT_AVAILABLE'));
      var entry = request(300000); entry.productId = productId; purchasePending = entry;
      var result = payload ? call('buyProductWithPayload', false, productId, payload) : call('buyProduct', false, productId);
      // Existing Java void methods return undefined; only explicit false means rejected.
      if (result === false) { purchasePending = null; entry.finish(fail('NOT_AVAILABLE')); }
      return entry.promise;
    },
    consume: function (token) {
      if (consumePending[token]) return consumePending[token].promise;
      var entry = request(30000); consumePending[token] = entry;
      if (call('consumePurchase', false, token) === false) { delete consumePending[token]; entry.finish(fail('NOT_AVAILABLE')); }
      return entry.promise;
    },
    getPurchases: function () {
      if (queryPending) return queryPending.promise;
      var entry = request(30000); queryPending = entry;
      if (call('getPurchases', false) === false) { queryPending = null; entry.finish(fail('NOT_AVAILABLE')); }
      return entry.promise;
    },
    isRemoveAdsOwned: function () { return call('isRemoveAdsOwned', false) === true; },
    openRatingPage: function () { return call('openRatingPage', false) === true; },
    openStorePage: function () { return call('openStorePage', false) === true; }
  };
  window.CafeBazaar.buyProduct = window.CafeBazaar.purchase.bind(window.CafeBazaar);
  window.CafeBazaar.buyProductWithPayload = window.CafeBazaar.buyProduct;
  window.CafeBazaar.consumePurchase = window.CafeBazaar.consume;
  window.CafeBazaar.rateApp = window.CafeBazaar.openRatingPage;
  window.BazaarBridge = window.CafeBazaar;
  window.CafeBazaarBridge = {
    onConnectionResult: function (value) { event('cafebazaar:connection', parse(value)); },
    onPurchaseResult: function (value) {
      var data = parse(value);
      if (purchasePending && purchasePending.productId === data.productId) {
        var entry = purchasePending; purchasePending = null; entry.finish(data);
      }
      event('cafebazaar:purchase', data);
    },
    onConsumeResult: function (value) {
      var data = parse(value), entry = consumePending[data.purchaseToken];
      if (entry) { delete consumePending[data.purchaseToken]; entry.finish(data); }
      event('cafebazaar:consume', data);
    },
    onPurchasesQueryResult: function (value) {
      var data = parse(value);
      if (queryPending) { var entry = queryPending; queryPending = null; entry.finish(data); }
      event('cafebazaar:purchases', data);
    },
    onOwnedProductsChanged: function (value) { event('cafebazaar:ownedproducts', parse(value)); }
  };
  window.addEventListener('nativeads:event', function (e) { adEvent(e.detail); });
  window.addEventListener('nativeapp:deeplink', function (e) { emit('app:deep_link', e.detail); });
})(window);
